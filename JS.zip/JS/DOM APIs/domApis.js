/**Las DOM APIs en JavaScript son un conjunto de interfaces que permiten manipular el Document Object Model (DOM), es decir, la estructura de un documento HTML o XML. Con estas APIs, puedes modificar elementos, agregar eventos, cambiar estilos y mucho más.
 */

/**🔹 Principales Métodos del DOM
1️⃣ Selección de Elementos */
document.getElementById("miElemento");  // Selecciona por ID
document.getElementsByClassName("miClase");  // Colección de elementos con esa clase
document.getElementsByTagName("div");  // Colección de elementos por etiqueta
document.querySelector(".miClase");  // Primer elemento que coincide con el selector
document.querySelectorAll("div p");  // Todos los elementos que coinciden

// 2️⃣ Modificación de Contenido
const elemento = document.getElementById("miElemento");
elemento.innerText = "Nuevo texto";  // Modifica el texto
elemento.innerHTML = "<b>Texto en negrita</b>";  // Inserta HTML
elemento.setAttribute("data-id", "123");  // Agrega un atributo

// 3️⃣ Modificación de Estilos
elemento.style.color = "red";  // Cambia el color del texto
elemento.style.backgroundColor = "yellow";  // Fondo amarillo

// 4️⃣ Manipulación del DOM (Crear, Agregar, Eliminar)
const nuevoElemento = document.createElement("p");
nuevoElemento.innerText = "Soy un nuevo párrafo";
document.body.appendChild(nuevoElemento);  // Agrega al final del <body>

document.getElementById("miElemento").remove();  // Elimina el elemento

// 5️⃣ Eventos
document.getElementById("boton").addEventListener("click", function() {
    alert("¡Has hecho clic!");
});

// Recorrer y Navegar el DOM
// Puedes moverte entre los elementos del documento usando propiedades como:
const padre = document.getElementById("miElemento").parentNode;  // Nodo padre
const hijos = document.getElementById("miElemento").children;  // Colección de hijos
const siguiente = document.getElementById("miElemento").nextElementSibling;  // Hermano siguiente
const anterior = document.getElementById("miElemento").previousElementSibling;  // Hermano anterior

// Manipulación Avanzada de Elementos
// Clonar Elementos
const original = document.getElementById("miElemento");
const clon = original.cloneNode(true);  // true para copiar contenido interno
document.body.appendChild(clon);

// Insertar Elementos de Forma Específica
const nuevoDiv = document.createElement("div");
nuevoDiv.innerText = "Nuevo div";
document.body.insertBefore(nuevoDiv, document.getElementById("referencia"));

// Trabajar con Clases y Atributos
elemento.classList.add("nuevaClase");  // Agregar clase
elemento.classList.remove("nuevaClase");  // Eliminar clase
elemento.classList.toggle("oscuro");  // Alternar clase (añadir si no está, quitar si está)

elemento.hasAttribute("data-info");  // Verifica si tiene un atributo
elemento.getAttribute("href");  // Obtiene el valor de un atributo
elemento.removeAttribute("disabled");  // Elimina un atributo

/**Manipulación de Formularios */
const inputValor = document.getElementById("miInput").value;  // Obtener valor
document.getElementById("miInput").value = "Nuevo texto";  // Modificar valor

// Eventos Avanzados
// Delegación de Eventos (Útil para elementos dinámicos)
document.getElementById("contenedor").addEventListener("click", (event) => {
    if (event.target.matches(".boton-clase")) {
        alert("Botón clickeado");
    }
});

// Eventos del Teclado y el Ratón
document.addEventListener("keydown", (event) => {
    console.log("Tecla presionada: " + event.key);
});

// Intersection Observer (Detectar Elementos en Pantalla)
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            console.log("Elemento visible");
        }
    });
});

observer.observe(document.getElementById("miElemento"));

// Modificar el DOM con innerHTML vs createElement
// ❌ NO recomendado: (Riesgo de inyección de código)
elemento.innerHTML = "<script>alert('Hackeado')</script>";

// ✅ Mejor opción: (Uso seguro de createElement)
const script = document.createElement("script");
script.innerText = "alert('Seguro')";
document.body.appendChild(script);
