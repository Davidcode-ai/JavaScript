// Object.is(a, b) → (SameValue Algorithm)
// ✅ Necesario en casos raros: detecta diferencias en NaN y -0.
// ⚠️ Se comporta como ===, excepto en estos casos:
// Object.is(NaN, NaN) === true (pero NaN === NaN es false).
// Object.is(-0, 0) === false (pero -0 === 0 es true).
// ¿Cuándo usarlo?
// 
// Si trabajas con valores especiales (NaN, -0).
// Cuando comparas claves en estructuras de datos avanzadas.

console.log(Object.is(NaN, NaN)); // true (a diferencia de ===)
console.log(Object.is(-0, 0)); // false (a diferencia de ===)
console.log(Object.is(5, 5)); // true (igual que ===)
