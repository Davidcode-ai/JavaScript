// 4️⃣ SameValueZero (usado en Set y Map)
// ✅ Funciona como Object.is(), pero trata -0 y 0 como iguales.
// Se usa en Set y Map, por lo que no necesitas implementarlo tú.
// ¿Cuándo se usa?
// 
// En estructuras de datos como Set y Map.
// Ejemplo con Set:

const mySet = new Set();
mySet.add(-0);
console.log(mySet.has(0)); // true (SameValueZero considera -0 y 0 iguales)
