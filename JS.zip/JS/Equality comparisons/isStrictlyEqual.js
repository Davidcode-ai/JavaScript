// 2️⃣ isStrictlyEqual(a, b) → (===) (Comparación estricta)
// ✅ Útil en la mayoría de los casos donde necesitas precisión en los tipos.
// ❌ No hace conversiones automáticas.
// ¿Cuándo usarlo?

// Casi siempre en código seguro y predecible.
function isStrictlyEqual(a, b) {
    return a === b;
}
console.log(isStrictlyEqual(0, false)); // false (¡correcto!)
console.log(isStrictlyEqual("5", 5)); // false
console.log(isStrictlyEqual(5, 5)); // true


