// 1️⃣ isLooselyEqual(a, b) → (==) (Comparación laxa)
// ✅ Útil cuando quieres que JavaScript haga conversiones automáticas.
// ⚠️ Peligroso porque puede dar resultados inesperados.
// ¿Cuándo usarlo?

// Cuando comparas valores de formularios ("5" con 5).
// Al comparar null y undefined sin preocuparte por cuál de los dos es.

function isLooselyEqual(a, b) {
    return a == b;
}
console.log(isLooselyEqual(0, false)); // true (¡cuidado!)
console.log(isLooselyEqual(null, undefined)); // true
