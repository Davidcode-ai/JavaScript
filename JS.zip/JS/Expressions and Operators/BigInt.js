// 🔹 ¿Qué es BigInt en JavaScript?
// En JavaScript, los números normales (Number) están limitados a 53 bits de precisión, lo que significa que no pueden representar números muy grandes con precisión.
// 
// 📌 Ejemplo del problema con números grandes:
console.log(9007199254740991 + 1); // 9007199254740992 ✅
console.log(9007199254740991 + 2); // 9007199254740992 ❌ (¡Error!)
// El resultado es incorrecto porque JavaScript ya no puede manejar bien números más allá de 2^53 - 1.

// Para resolver esto, JavaScript introdujo BigInt, que permite manejar números enormes sin perder precisión.
// 
// 📌 Cómo crear un BigInt
// Para definir un número BigInt, puedes usar la letra n al final del número o la función BigInt().
// 
// Ejemplo 1: Usando n al final
let numeroGrande = 9007199254740991n;
console.log(numeroGrande); // 9007199254740991n

// 📌 Operaciones con BigInt
// Puedes hacer casi todas las operaciones matemáticas como con Number, pero NO puedes mezclar BigInt con Number.
// 
// Ejemplo 1: Sumas y restas
let a = 1000000000000000000n;
let b = 2000000000000000000n;
console.log(a + b); // 3000000000000000000n
console.log(b - a); // 1000000000000000000n

// Ejemplo 2: Multiplicación y división
console.log(10n * 3n); // 30n
console.log(10n / 3n); // 3n (¡Ojo! No hay decimales)

// División en BigInt siempre redondea hacia abajo (no hay decimales).
// 
// Comparaciones con BigInt
// Puedes comparar BigInt y Number sin problemas:
console.log(5n > 2);  // ✅ true
console.log(5n == 5); // ✅ true (porque `==` hace conversión automática)
console.log(5n === 5); // ❌ false (porque `===` compara tipos también)
// 
// 📌 ¿Cuándo usar BigInt?
// ✅ Cuando trabajas con números más grandes que 2^53 - 1.
// ✅ En criptografía, blockchain y manejo de grandes cantidades de datos.
// ✅ Cuando necesitas cálculos precisos sin errores de redondeo.