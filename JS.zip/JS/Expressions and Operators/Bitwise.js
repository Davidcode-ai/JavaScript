// 📌 Operadores bitwise explicados fácil
// Cada operador hace algo distinto con los 1 y 0. Veamos uno por uno:
// 
// 1️⃣ AND (&) → Solo devuelve 1 cuando ambos números tienen 1
// Este operador compara cada bit y solo deja 1 si ambos números tienen 1 en la misma posición.
// 
// Ejemplo

console.log(5 & 3);

// Veamos cómo funciona en binario:
// 5  =  101  
// 3  =  011  
// ----------------
// AND    =  001  →  1
// 
// 📌 Resultado: 1
// 
// ✅ Sirve para: Ver qué bits tienen activado el mismo valor en ambos números.
// 
// 2️⃣ OR (|) → Devuelve 1 si al menos uno de los números tiene 1
// Este operador compara cada bit y pone 1 si al menos uno de los números tiene 1.
// 
// Ejemplo
console.log(5 | 3);

// Veamos cómo funciona en binario:
// 5  =  101  
// 3  =  011  
// ----------------
// OR     =  111  →  7
// 
// 📌 Resultado: 7
// 
// ✅ Sirve para: Encender bits en una máscara de configuración.
// 
// 3️⃣ XOR (^) → Devuelve 1 si los bits son diferentes
// Este operador compara cada bit y devuelve 1 si los bits son distintos.
// 
// Ejemplo

console.log(5 ^ 3);

// Veamos cómo funciona en binario:
// 
// 5  =  101  
// 3  =  011  
// ----------------
// XOR    =  110  →  6
// 
// 📌 Resultado: 6
// 
// ✅ Sirve para: Alternar bits o hacer encriptación simple.

// 4️⃣ NOT (~) → Invierte los bits (1 a 0 y 0 a 1)
// Este operador cambia todos los 1 por 0 y los 0 por 1.
// 
// Ejemplo

console.log(~5);

// Veamos cómo funciona en binario (con 32 bits):
// 
// 5   =  00000000 00000000 00000000 00000101  
// ~5   =  11111111 11111111 11111111 11111010  
// 
// 📌 Resultado: -6 (JavaScript usa complemento a dos para representar números negativos).
// 
// ✅ Sirve para: Crear números negativos rápidamente.
// 
// 5️⃣ Shift Left (<<) → Mueve los bits a la izquierda
// Este operador desplaza los bits a la izquierda, lo que multiplica el número por 2^n.
// 
// Ejemplo
console.log(5 << 1);

// 5  =  00000000 00000000 00000000 00000101  
// <<1  =  00000000 00000000 00000000 00001010  →  10
// 
// 📌 Resultado: 10
// 
// ✅ Sirve para: Multiplicaciones rápidas por potencias de 2.
// 
// 6️⃣ Shift Right (>>) → Mueve los bits a la derecha (manteniendo el signo)
// Este operador desplaza los bits a la derecha, lo que divide el número por 2^n.
// 
// Ejemplo
console.log(5 >> 1);


// 5  =  00000000 00000000 00000000 00000101  
// >>1  =  00000000 00000000 00000000 00000010  →  2
// 
// 📌 Resultado: 2
// 
// ✅ Sirve para: Divisiones rápidas por potencias de 2.
// 
// 7️⃣ Shift Right sin signo (>>>) → Mueve los bits a la derecha pero rellena con 0
// Este operador es como >>, pero en lugar de mantener el signo, pone 0 en los nuevos espacios.
// 
// Ejemplo
console.log(-5 >>> 1);
// 
// -5   =  11111111 11111111 11111111 11111011  
// >>>1   =  01111111 11111111 11111111 11111101  →  2147483645
// 
// 📌 Resultado: 2147483645
// 
// // ✅ Sirve para: Trabajar con números sin signo en binario.