// Funciones y métodos "built-in" en JavaScript
// En JavaScript, "built-in" (o integradas) hace referencia a las funciones y objetos que ya vienen predefinidos dentro del lenguaje, lo que significa que no necesitas definirlos tú mismo. Estas funciones y objetos están disponibles desde el momento en que trabajas con JavaScript, y pueden ser utilizados en cualquier parte de tu código sin necesidad de importarlos o escribirlos.
// 
// 📌 Categorías de funciones y objetos built-in en JavaScript:
// Objetos Globales: Estos son objetos y funciones que están disponibles de manera global en todo el entorno de JavaScript. Ejemplos incluyen:
// 
// Object: Para trabajar con objetos.
// Array: Para trabajar con arrays.
// String: Para trabajar con cadenas de texto.
// Number: Para trabajar con números.
// Boolean: Para trabajar con valores booleanos (true o false).
// Date: Para manejar fechas y horas.
// Math: Para realizar operaciones matemáticas.
// JSON: Para trabajar con datos en formato JSON.
// Funciones Built-in Comunes: Son funciones que puedes usar para realizar tareas comunes. Algunas de las más conocidas son:
// 
// console.log(): Para imprimir valores en la consola.
// setTimeout(): Para ejecutar una función después de un cierto período de tiempo.
// setInterval(): Para ejecutar una función repetidamente en intervalos de tiempo.
// parseInt(): Para convertir una cadena de texto a un número entero.
// parseFloat(): Para convertir una cadena de texto a un número decimal.
// isNaN(): Para verificar si un valor no es un número.
// 