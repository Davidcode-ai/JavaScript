/**Parámetros Rest en JavaScript
Los parámetros Rest (...) permiten que una función reciba un número indeterminado de argumentos como un solo array. Esto es muy útil cuando no sabemos cuántos parámetros se pasarán a la función, y queremos poder manejarlo sin tener que especificar cada uno de ellos.

📌 ¿Cómo funcionan los parámetros Rest?
Cuando usamos ... antes de un parámetro en una función, todos los valores adicionales pasados se agruparán en un array.

Ejemplo básico: */

function listarNombres(primerNombre, ...otrosNombres) {
    console.log("Primer nombre:", primerNombre);
    console.log("Otros nombres:", otrosNombres.join(", "));
  }
  
  listarNombres("Juan", "Pedro", "María", "Ana");
  // Resultado:
  // Primer nombre: Juan
  // Otros nombres: Pedro, María, Ana