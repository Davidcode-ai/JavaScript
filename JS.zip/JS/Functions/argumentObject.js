/**🔹 El objeto arguments en JavaScript
El objeto arguments es una lista similar a un array (pero no un array real) que contiene todos los parámetros que fueron pasados a una función, sin importar cuántos parámetros hayas declarado en la definición de la función.

Este objeto es útil para manejar funciones con un número indeterminado de parámetros, como si fuera un array, incluso si no usas parámetros rest (...).

📌 Características del objeto arguments:
Es accesible solo dentro de funciones.
No es un array verdadero, pero tiene una estructura similar: puedes acceder a los elementos usando índices (arguments[0], arguments[1], etc.).
No tiene métodos de array como .map(), .forEach(), etc. (a diferencia de un array normal).
Tiene la propiedad length, que indica cuántos argumentos fueron pasados a la función.
 */

function sumar() {
    let total = 0;
    for (let i = 0; i < arguments.length; i++) {
      total += arguments[i];
    }
    return total;
  }
  
  console.log(sumar(1, 2, 3, 4)); // 10
  console.log(sumar(5, 5));       // 10
  
/**De normal usar rest a menos que se den los siguientes casos: 
 * Casos donde arguments podría ser necesario:
Funciones tradicionales que no usan parámetros rest:

Si estás trabajando en una función tradicional (no flecha) y necesitas acceder a todos los parámetros sin un array real, puedes usar arguments. Sin embargo, este caso es cada vez menos frecuente.

Compatibilidad con código antiguo:

Si trabajas en proyectos heredados o necesitas compatibilidad con código antiguo que usa funciones tradicionales y no tiene soporte para los parámetros rest, arguments puede ser necesario.
 */