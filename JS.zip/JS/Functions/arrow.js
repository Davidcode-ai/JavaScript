// 🔹 Funciones Flecha (Arrow Functions) en JavaScript
// Las funciones flecha (o arrow functions) son una forma más compacta y concisa de escribir funciones en JavaScript. Introducidas en ECMAScript 6 (ES6), las funciones flecha tienen varias ventajas, como una sintaxis más corta y no tienen su propio this, lo que puede evitar algunos problemas comunes con las funciones tradicionales.
// 
// 📌 Sintaxis básica de las funciones flecha:

const funcion = (param1, param2) => {
    return param1 + param2;
  };

//   O si la función tiene una sola expresión, puedes omitir el return y las llaves {}.

const sumar = (a, b) => a + b; // Si solo hay una expresión, el valor es retornado automáticamente

// 📌 Comparando con una función tradicional:
// Función tradicional:

function multiplicar(a, b) {
    return a * b;
  }

//   Función flecha:
const multiplicar = (a, b) => a * b;

// Ventajas:
// 
// Sintaxis más corta.
// Si hay una sola expresión, no necesitas usar return ni llaves {}.

/**📌 Reglas de la función flecha:
Sin this propio:
Las funciones flecha no tienen su propio this. El valor de this se hereda del contexto de la función externa. Esto puede ser útil cuando estamos trabajando con callbacks o en métodos dentro de objetos, y queremos evitar que this cambie.
Ejemplo: Función normal vs. flecha */

function Persona() {
    this.edad = 25;
    
    // Función normal
    setInterval(function() {
      this.edad++; // 'this' no se refiere al objeto Persona, causa un error
      console.log(this.edad);
    }, 1000);
  }
  
  const persona1 = new Persona();

  /**Esto fallará porque this dentro de la función setInterval no hace referencia al objeto persona1.

Pero con una función flecha, heredamos el this del contexto exterior: */

function Persona() {
    this.edad = 25;
    
    // Función flecha
    setInterval(() => {
      this.edad++; // 'this' sí se refiere al objeto Persona
      console.log(this.edad);
    }, 1000);
  }
  
  const persona2 = new Persona(); // Funciona correctamente

/**Parámetros predeterminados:
Puedes usar parámetros predeterminados en las funciones flecha, igual que con las funciones tradicionales. */
const saludar = (nombre = "Invitado") => {
    console.log(`Hola, ${nombre}!`);
  };
  
  saludar("Carlos");  // Hola, Carlos!
  saludar();          // Hola, Invitado!
  
  /**📌 Funciones de una sola línea:
Si la función tiene solo una expresión, puedes omitir las llaves {} y el return. */
const duplicar = x => x * 2;

console.log(duplicar(4)); // 8

/**No requiere el uso de function:
A diferencia de las funciones tradicionales, no es necesario usar la palabra clave function, lo que hace que el código sea más limpio.

Función tradicional: */
function saludo() {
    return "¡Hola!";
  }
  
  /**Función flecha: */
  const saludo = () => "¡Hola!";

  /**📌 Función flecha con un solo parámetro:
Si tienes un solo parámetro, puedes omitir los paréntesis: */
const cuadrado = x => x * x;

console.log(cuadrado(5)); // 25

/** Resumen:
Las funciones flecha ofrecen una sintaxis más corta y no tienen su propio this.
Son ideales para funciones anónimas o de una sola línea.
Son útiles cuando necesitas preservar el contexto de this en funciones callback o métodos dentro de objetos. */