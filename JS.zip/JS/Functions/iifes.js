// 🔹 IIFE (Immediately Invoked Function Expression)
// Una IIFE es una expresión de función ejecutada inmediatamente después de ser definida. Se utiliza para crear un nuevo ámbito (scope) en JavaScript, lo que puede ayudar a evitar la contaminación del espacio de nombres global y a mantener el código más organizado.

(function() {
    const secreto = "Este es un valor secreto";
    console.log(secreto); // "Este es un valor secreto"
  })();
  
  console.log(secreto); // Error: secreto no está definido
  
  /**📌 Resumen:
IIFE es una expresión de función ejecutada inmediatamente.
Se usa para aislar el código y evitar que las variables y funciones se mezclen con el ámbito global.
Es útil cuando necesitas ejecutar algo solo una vez, como la inicialización de valores, sin dejar residuos en el espacio de nombres global. */