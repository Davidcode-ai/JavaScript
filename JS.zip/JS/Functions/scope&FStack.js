/**🔹 Scope y Call Stack en JavaScript
Scope (alcance) y Call Stack (pila de llamadas) son conceptos fundamentales en JavaScript que definen cómo y cuándo las variables y funciones son accesibles y ejecutadas.

📌 1. Scope (Ámbito)
El scope es el contexto en el que una variable o función es accesible. En JavaScript, existen diferentes tipos de scope que definen la visibilidad de las variables y funciones:

Global Scope:

Las variables declaradas fuera de cualquier función están en el scope global y son accesibles desde cualquier parte del código. */
let globalVar = "Hola, soy global";

function mostrarGlobal() {
  console.log(globalVar); // Se puede acceder a globalVar
}
mostrarGlobal(); // "Hola, soy global"
/**Function Scope:

Las variables declaradas dentro de una función solo son accesibles dentro de esa función. Este es el scope local. */
function mostrarLocal() {
    let localVar = "Hola, soy local";
    console.log(localVar); // Se puede acceder a localVar dentro de la función
  }
  mostrarLocal(); // "Hola, soy local"
  console.log(localVar); // Error: localVar is not defined
  
  /**Block Scope (Con let y const):

Las variables declaradas con let o const dentro de un bloque {} solo son accesibles dentro de ese bloque, incluso si están dentro de una función. */
if (true) {
    let blockVar = "Soy de bloque";
    console.log(blockVar); // Se puede acceder dentro del bloque
  }
  console.log(blockVar); // Error: blockVar is not defined
  
  /**2. Call Stack (Pila de Llamadas)
El Call Stack es una estructura de datos que lleva el registro de las funciones que se están ejecutando. Cada vez que se llama a una función, se agrega a la pila. Cuando una función termina, se elimina de la pila.

Cómo funciona:
La función principal (la primera) se coloca en la parte superior de la pila.
Si se llama a una función dentro de esa función, esta nueva función se coloca encima de la primera en la pila.
Cuando una función termina su ejecución, se elimina de la pila. */
function funcionA() {
    console.log("A");
    funcionB();
  }
  
  function funcionB() {
    console.log("B");
  }
  
  funcionA();
  
  /**🔹 Orden de ejecución:

funcionA() se coloca en la pila.
funcionB() se coloca en la pila desde dentro de funcionA().
funcionB() termina y se elimina de la pila.
Luego, funcionA() termina y se elimina de la pila. */
// Resultado
// A
// B
