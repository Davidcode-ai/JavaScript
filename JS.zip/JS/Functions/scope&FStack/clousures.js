/**🔹 Closures (Cierres)
Un closure es una función que retiene el acceso a las variables del scope en el que fue creada, incluso cuando esa función se ejecuta fuera de su contexto original.

Los closures permiten que una función recuerde y acceda a variables de su entorno léxico (scope léxico), aunque el código que las contiene haya terminado de ejecutarse.
Ejemplo de closure: */
function crearContador() {
    let contador = 0;
    
    return function() {
      contador++;
      console.log(contador);
    };
  }
  
  const contador1 = crearContador();
  contador1(); // 1
  contador1(); // 2
  
  /**🔹 Explicación:

La función interna retiene el acceso a la variable contador, incluso después de que la función crearContador() haya terminado su ejecución. Este es un ejemplo clásico de closure. */