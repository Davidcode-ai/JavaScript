/**🔹 Lexical Scoping (Ámbito Léxico)
Lexical scoping se refiere a cómo JavaScript determina el scope de una variable en función de dónde se declara, no de dónde se ejecuta.

Las funciones heredan el scope de su contexto de declaración (no el contexto de su ejecución). Esto significa que una función tiene acceso a las variables de su ámbito exterior en el momento de su declaración.
Ejemplo de lexical scoping: */
function outerFunction() {
    let variableExterna = "Soy externa";
    
    function innerFunction() {
      console.log(variableExterna); // Accede a variableExterna
    }
    
    innerFunction();
  }
  
  outerFunction(); // "Soy externa"
  
  /**🔹 Explicación:

innerFunction() tiene acceso a variableExterna porque fue declarada dentro de outerFunction(), gracias al lexical scoping. */