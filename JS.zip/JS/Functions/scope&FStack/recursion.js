/** Recursión en JavaScript
La recursión es el proceso en el que una función se llama a sí misma para resolver un problema. Cada vez que la función se llama, trabaja con una versión más simple del problema original, hasta que llega a una condición base que detiene las llamadas recursivas.

Ejemplo básico de recursión (Cálculo del factorial): */
function factorial(n) {
    if (n === 0) return 1; // Condición base
    return n * factorial(n - 1); // Llamada recursiva
  }
  
  console.log(factorial(5)); // 120
  
  /**🔹 Explicación:

La función factorial() se llama a sí misma con un valor decreciente de n hasta que n llega a 0 (condición base), momento en el cual devuelve 1 y empieza a resolver las llamadas anteriores. */