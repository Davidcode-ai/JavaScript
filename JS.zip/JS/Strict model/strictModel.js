/** 🔹 Strict Mode en JavaScript
El Strict Mode ("modo estricto") es una característica de JavaScript que ayuda a escribir un código más seguro y limpio. Se activa con la instrucción:*/
"use strict";

/**🚀 ¿Qué hace el Strict Mode?
Evita el uso de variables sin declarar */
"use strict";
x = 10;  // ❌ Error: x is not defined

/**Impide la asignación a variables read-only o protegidas */
"use strict";
NaN = 5;  // ❌ Error: No se puede asignar a NaN

/**Prohíbe eliminar variables, funciones y objetos no eliminables */
"use strict";
var obj = { nombre: "David" };
// delete obj;  // ❌ Error: No se puede eliminar un objeto

/**Detecta nombres de parámetros duplicados en funciones */
"use strict";
function suma(a, a) {  // ❌ Error: Parámetros duplicados
    return a + a;
}

/**Prohíbe el uso de with (porque puede causar ambigüedad) */
"use strict";
// with (Math) { x = cos(2) }  // ❌ Error

/**Hace que this en funciones normales sea undefined en lugar de window */
"use strict";
function mostrar() {
    console.log(this);  // 🔍 Sin strict mode: `window`
                       // 🔍 Con strict mode: `undefined`
}
mostrar();

/**✅ ¿Cómo activar Strict Mode?
1️⃣ A nivel global */
"use strict";
// Todo el código aquí se ejecuta en modo estricto

/**2️⃣ A nivel de función */
function miFuncion() {
    "use strict";
    // Solo este bloque usa Strict Mode
}

/**❓ ¿Debo usar Strict Mode?
✔ Sí, en proyectos modernos, ya que previene errores y ayuda a escribir mejor código.
⚠ No, si trabajas con código antiguo que podría romperse con las restricciones.

Resumen: El Strict Mode en JavaScript ayuda a evitar errores comunes y hace que el código sea más seguro. ¡Úsalo siempre que puedas! 🚀 */